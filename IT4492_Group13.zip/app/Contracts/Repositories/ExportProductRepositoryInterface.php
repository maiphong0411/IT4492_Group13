<?php


namespace App\Contracts\Repositories;


interface SoldProductRepositoryInterFace extends BaseRepositoryInterface
{

}