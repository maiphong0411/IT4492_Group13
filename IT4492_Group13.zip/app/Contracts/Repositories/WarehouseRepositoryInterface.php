<?php


namespace App\Contracts\Repositories;


interface WarehouseRepositoryInterFace extends BaseRepositoryInterface
{

}