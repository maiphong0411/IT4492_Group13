<?php


namespace App\Contracts\Repositories;


interface ProductRepositoryInterFace extends BaseRepositoryInterface
{

}
