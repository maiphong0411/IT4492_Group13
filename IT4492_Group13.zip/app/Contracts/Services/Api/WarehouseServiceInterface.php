<?php


namespace App\Contracts\Services\Api;


interface WarehouseServiceInterface
{

}
